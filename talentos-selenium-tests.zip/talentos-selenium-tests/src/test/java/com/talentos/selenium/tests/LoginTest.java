package com.talentos.selenium.tests;

import com.talentos.selenium.config.BaseTest;
import com.talentos.selenium.pages.LoginPage;
import com.talentos.selenium.utils.TestLogger;
import com.talentos.selenium.utils.WaitHelper;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

/**
 * LoginTest — tests for login.component.html
 *
 * Test cases:
 *   TC-L-01  Login page loads at /login
 *   TC-L-02  Brand name "TalentOS" is displayed
 *   TC-L-03  Form title is "Sign in"
 *   TC-L-04  Login with empty fields shows validation (submit is disabled)
 *   TC-L-05  Login with invalid credentials shows error message
 *   TC-L-06  Student login redirects to /student/dashboard
 *   TC-L-07  Admin login redirects to /admin/dashboard
 *   TC-L-08  Register link navigates to /register
 *   TC-L-09  Root URL "/" redirects to /login
 */
public class LoginTest extends BaseTest {

    private LoginPage loginPage;

    @BeforeClass
    public void initPage() {
        TestLogger.separator("LOGIN TESTS");
        loginPage = new LoginPage(driver);
    }

    @Test(priority = 1, description = "TC-L-01: Login page loads at /login")
    public void testLoginPageLoads() {
        try {
            loginPage.open(BASE_URL);
            Assert.assertTrue(loginPage.isOnLoginPage(),
                    "URL should contain /login");
            TestLogger.pass("TC-L-01: Login page loads at /login");
        } catch (AssertionError | Exception e) {
            TestLogger.fail("TC-L-01", e.getMessage());
            throw e;
        }
    }

    @Test(priority = 2, description = "TC-L-02: TalentOS brand name is visible on login page")
    public void testBrandNameVisible() {
        try {
            loginPage.open(BASE_URL);
            String brand = loginPage.getBrandName();
            Assert.assertEquals(brand, "TalentOS",
                    "Brand name should be TalentOS");
            TestLogger.pass("TC-L-02: Brand name 'TalentOS' visible");
        } catch (AssertionError | Exception e) {
            TestLogger.fail("TC-L-02", e.getMessage());
            throw e;
        }
    }

    @Test(priority = 3, description = "TC-L-03: Form title is 'Sign in'")
    public void testFormTitle() {
        try {
            loginPage.open(BASE_URL);
            String title = loginPage.getFormTitle();
            Assert.assertEquals(title, "Sign in",
                    "Form title should be 'Sign in'");
            TestLogger.pass("TC-L-03: Form title is 'Sign in'");
        } catch (AssertionError | Exception e) {
            TestLogger.fail("TC-L-03", e.getMessage());
            throw e;
        }
    }

    @Test(priority = 4, description = "TC-L-04: Invalid credentials shows error alert")
    public void testInvalidLoginShowsError() {
        try {
            loginPage.open(BASE_URL);
            loginPage.loginAs("wrong@email.com", "wrongpassword");
            // Wait briefly for error to appear
            WaitHelper.sleep(2000);
            String error = loginPage.getErrorMessage();
            Assert.assertFalse(error.isEmpty(),
                    "Error message should be shown for invalid credentials");
            TestLogger.pass("TC-L-04: Invalid login shows error: " + error);
        } catch (AssertionError | Exception e) {
            TestLogger.fail("TC-L-04", e.getMessage());
            throw e;
        }
    }

    @Test(priority = 5, description = "TC-L-05: Student login redirects to student dashboard")
    public void testStudentLoginRedirectsToDashboard() {
        try {
            loginPage.open(BASE_URL);
            loginPage.loginAs(STUDENT_EMAIL, STUDENT_PASSWORD);
            WaitHelper.sleep(3000);
            String currentUrl = driver.getCurrentUrl();
            Assert.assertTrue(currentUrl.contains("/student/dashboard"),
                    "Student should be redirected to /student/dashboard. Actual URL: " + currentUrl);
            TestLogger.pass("TC-L-05: Student login → redirected to " + currentUrl);
        } catch (AssertionError | Exception e) {
            TestLogger.fail("TC-L-05", e.getMessage());
            throw e;
        }
    }

    @Test(priority = 6, description = "TC-L-06: Admin login redirects to admin dashboard")
    public void testAdminLoginRedirectsToDashboard() {
        try {
            loginPage.open(BASE_URL);
            loginPage.loginAs(ADMIN_EMAIL, ADMIN_PASSWORD);
            WaitHelper.sleep(3000);
            String currentUrl = driver.getCurrentUrl();
            Assert.assertTrue(currentUrl.contains("/admin"),
                    "Admin should be redirected to /admin. Actual URL: " + currentUrl);
            TestLogger.pass("TC-L-06: Admin login → redirected to " + currentUrl);
        } catch (AssertionError | Exception e) {
            TestLogger.fail("TC-L-06", e.getMessage());
            throw e;
        }
    }

    @Test(priority = 7, description = "TC-L-07: Register link navigates to /register")
    public void testRegisterLinkNavigates() {
        try {
            loginPage.open(BASE_URL);
            loginPage.clickRegisterLink();
            WaitHelper.sleep(1500);
            Assert.assertTrue(driver.getCurrentUrl().contains("/register"),
                    "Clicking register link should navigate to /register");
            TestLogger.pass("TC-L-07: Register link navigates to /register");
        } catch (AssertionError | Exception e) {
            TestLogger.fail("TC-L-07", e.getMessage());
            throw e;
        }
    }

    @Test(priority = 8, description = "TC-L-08: Root URL '/' redirects to /login")
    public void testRootRedirectsToLogin() {
        try {
            driver.get(BASE_URL + "/");
            WaitHelper.sleep(1500);
            Assert.assertTrue(driver.getCurrentUrl().contains("/login"),
                    "Root URL should redirect to /login");
            TestLogger.pass("TC-L-08: Root URL redirects to /login");
        } catch (AssertionError | Exception e) {
            TestLogger.fail("TC-L-08", e.getMessage());
            throw e;
        }
    }
}
