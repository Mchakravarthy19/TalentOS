package com.talentos.selenium.pages;

import com.talentos.selenium.utils.WaitHelper;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

/**
 * RegisterPage — matches register.component.html
 *
 * Role cards use CSS class .role-card — we find by the role-title text inside.
 * The Student card has text "Student", Recruiter card has "Recruiter".
 */
public class RegisterPage {

    private final WebDriver driver;
    private final WaitHelper wait;

    private final By nameInput      = By.cssSelector("input[formcontrolname='name']");
    private final By emailInput     = By.cssSelector("input[formcontrolname='email']");
    private final By passwordInput  = By.cssSelector("input[formcontrolname='password']");
    private final By submitBtn      = By.cssSelector("button.btn-auth-submit");
    private final By errorAlert     = By.cssSelector(".alert.alert-danger span");
    private final By formTitle      = By.cssSelector(".auth-form-title");
    private final By loginLink      = By.cssSelector("a[href='/login']");

    // Role cards — located by the visible text inside .role-title
    private final By studentRoleCard   = By.xpath("//div[@class='role-card']//div[@class='role-title' and text()='Student']/ancestor::div[@class='role-card']");
    private final By recruiterRoleCard = By.xpath("//div[@class='role-card']//div[@class='role-title' and text()='Recruiter']/ancestor::div[@class='role-card']");

    public RegisterPage(WebDriver driver) {
        this.driver = driver;
        this.wait   = new WaitHelper(driver);
    }

    public void open(String baseUrl) {
        driver.get(baseUrl + "/register");
    }

    public void selectStudentRole() {
        wait.clickable(studentRoleCard).click();
    }

    public void selectRecruiterRole() {
        wait.clickable(recruiterRoleCard).click();
    }

    public void enterName(String name) {
        wait.visible(nameInput).clear();
        wait.visible(nameInput).sendKeys(name);
    }

    public void enterEmail(String email) {
        wait.visible(emailInput).clear();
        wait.visible(emailInput).sendKeys(email);
    }

    public void enterPassword(String password) {
        wait.visible(passwordInput).clear();
        wait.visible(passwordInput).sendKeys(password);
    }

    public void clickSubmit() {
        wait.clickable(submitBtn).click();
    }

    public void registerAs(String role, String name, String email, String password) {
        if ("STUDENT".equalsIgnoreCase(role))    selectStudentRole();
        else                                      selectRecruiterRole();
        enterName(name);
        enterEmail(email);
        enterPassword(password);
        clickSubmit();
    }

    public String getErrorMessage() {
        return wait.visible(errorAlert).getText();
    }

    public String getFormTitle() {
        return wait.visible(formTitle).getText();
    }

    public void clickLoginLink() {
        wait.clickable(loginLink).click();
    }
}
