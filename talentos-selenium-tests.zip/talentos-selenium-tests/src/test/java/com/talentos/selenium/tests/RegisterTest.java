package com.talentos.selenium.tests;

import com.talentos.selenium.config.BaseTest;
import com.talentos.selenium.pages.LoginPage;
import com.talentos.selenium.pages.RegisterPage;
import com.talentos.selenium.utils.TestLogger;
import com.talentos.selenium.utils.WaitHelper;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.UUID;

/**
 * RegisterTest — tests for register.component.html
 *
 * Test cases:
 *   TC-R-01  Register page loads at /register
 *   TC-R-02  Form title is "Create account"
 *   TC-R-03  Student role card is selectable
 *   TC-R-04  Recruiter role card is selectable
 *   TC-R-05  Register new student with valid data succeeds (redirects to login or dashboard)
 *   TC-R-06  Register with duplicate email shows error
 *   TC-R-07  Register with short password shows validation error
 *   TC-R-08  Sign in link navigates back to /login
 */
public class RegisterTest extends BaseTest {

    private RegisterPage registerPage;
    private LoginPage loginPage;

    @BeforeClass
    public void initPage() {
        TestLogger.separator("REGISTER TESTS");
        registerPage = new RegisterPage(driver);
        loginPage    = new LoginPage(driver);
    }

    @Test(priority = 1, description = "TC-R-01: Register page loads at /register")
    public void testRegisterPageLoads() {
        try {
            registerPage.open(BASE_URL);
            Assert.assertTrue(driver.getCurrentUrl().contains("/register"),
                    "URL should contain /register");
            TestLogger.pass("TC-R-01: Register page loads");
        } catch (AssertionError | Exception e) {
            TestLogger.fail("TC-R-01", e.getMessage());
            throw e;
        }
    }

    @Test(priority = 2, description = "TC-R-02: Form title is 'Create account'")
    public void testFormTitle() {
        try {
            registerPage.open(BASE_URL);
            String title = registerPage.getFormTitle();
            Assert.assertEquals(title, "Create account",
                    "Form title should be 'Create account'");
            TestLogger.pass("TC-R-02: Form title is 'Create account'");
        } catch (AssertionError | Exception e) {
            TestLogger.fail("TC-R-02", e.getMessage());
            throw e;
        }
    }

    @Test(priority = 3, description = "TC-R-03: Student role card is selectable")
    public void testStudentRoleCardSelectable() {
        try {
            registerPage.open(BASE_URL);
            registerPage.selectStudentRole();
            // No exception = click worked
            TestLogger.pass("TC-R-03: Student role card is clickable");
        } catch (AssertionError | Exception e) {
            TestLogger.fail("TC-R-03", e.getMessage());
            throw e;
        }
    }

    @Test(priority = 4, description = "TC-R-04: Recruiter role card is selectable")
    public void testRecruiterRoleCardSelectable() {
        try {
            registerPage.open(BASE_URL);
            registerPage.selectRecruiterRole();
            TestLogger.pass("TC-R-04: Recruiter role card is clickable");
        } catch (AssertionError | Exception e) {
            TestLogger.fail("TC-R-04", e.getMessage());
            throw e;
        }
    }

    @Test(priority = 5, description = "TC-R-05: Register new student with valid data")
    public void testRegisterNewStudentSuccess() {
        try {
            // Use a random email so it never conflicts
            String uniqueEmail = "student_" + UUID.randomUUID().toString().substring(0, 8) + "@test.com";
            registerPage.open(BASE_URL);
            registerPage.registerAs("STUDENT", "Test Student", uniqueEmail, "password123");
            WaitHelper.sleep(3000);
            String url = driver.getCurrentUrl();
            // After registration app typically redirects to login or straight to dashboard
            Assert.assertTrue(
                    url.contains("/login") || url.contains("/student"),
                    "After registration should redirect to login or dashboard. Actual: " + url);
            TestLogger.pass("TC-R-05: New student registered → redirected to " + url);
        } catch (AssertionError | Exception e) {
            TestLogger.fail("TC-R-05", e.getMessage());
            throw e;
        }
    }

    @Test(priority = 6, description = "TC-R-06: Register with duplicate email shows error")
    public void testDuplicateEmailShowsError() {
        try {
            registerPage.open(BASE_URL);
            // STUDENT_EMAIL is an existing user — should fail
            registerPage.registerAs("STUDENT", "Duplicate", STUDENT_EMAIL, STUDENT_PASSWORD);
            WaitHelper.sleep(2000);
            String error = registerPage.getErrorMessage();
            Assert.assertFalse(error.isEmpty(),
                    "Duplicate email should show an error message");
            TestLogger.pass("TC-R-06: Duplicate email shows error: " + error);
        } catch (AssertionError | Exception e) {
            TestLogger.fail("TC-R-06", e.getMessage());
            throw e;
        }
    }

    @Test(priority = 7, description = "TC-R-07: Sign-in link on register page navigates to /login")
    public void testSignInLinkNavigatesToLogin() {
        try {
            registerPage.open(BASE_URL);
            registerPage.clickLoginLink();
            WaitHelper.sleep(1500);
            Assert.assertTrue(driver.getCurrentUrl().contains("/login"),
                    "Sign in link should navigate to /login");
            TestLogger.pass("TC-R-07: Sign-in link navigates to /login");
        } catch (AssertionError | Exception e) {
            TestLogger.fail("TC-R-07", e.getMessage());
            throw e;
        }
    }
}
