package com.talentos.selenium.tests;

import com.talentos.selenium.config.BaseTest;
import com.talentos.selenium.pages.LoginPage;
import com.talentos.selenium.pages.NavbarPage;
import com.talentos.selenium.pages.RecruiterPages;
import com.talentos.selenium.utils.TestLogger;
import com.talentos.selenium.utils.WaitHelper;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

/**
 * RecruiterTest — covers recruiter dashboard, my-jobs, and job-form pages.
 *
 * Test cases:
 *   TC-RC-01  Recruiter login redirects to /recruiter/dashboard
 *   TC-RC-02  Recruiter dashboard navbar title is visible
 *   TC-RC-03  User chip shows recruiter role
 *   TC-RC-04  Stat cards are present on recruiter dashboard
 *   TC-RC-05  Recruiter can navigate to /recruiter/jobs
 *   TC-RC-06  My Jobs page loads
 *   TC-RC-07  Post a Job page loads at /recruiter/jobs/new
 *   TC-RC-08  Job form has required fields (title, company, description)
 *   TC-RC-09  Submitting empty job form shows validation
 *   TC-RC-10  Recruiter role guard blocks student from /recruiter routes
 */
public class RecruiterTest extends BaseTest {

    private LoginPage loginPage;
    private NavbarPage navbarPage;
    private RecruiterPages.DashboardPage dashboardPage;
    private RecruiterPages.MyJobsPage myJobsPage;
    private RecruiterPages.JobFormPage jobFormPage;

    @BeforeClass
    public void loginAsRecruiter() {
        TestLogger.separator("RECRUITER TESTS");
        loginPage     = new LoginPage(driver);
        navbarPage    = new NavbarPage(driver);
        dashboardPage = new RecruiterPages.DashboardPage(driver);
        myJobsPage    = new RecruiterPages.MyJobsPage(driver);
        jobFormPage   = new RecruiterPages.JobFormPage(driver);

        loginPage.open(BASE_URL);
        loginPage.loginAs(RECRUITER_EMAIL, RECRUITER_PASSWORD);
        WaitHelper.sleep(3000);
    }

    @Test(priority = 1, description = "TC-RC-01: Recruiter lands on /recruiter/dashboard after login")
    public void testRecruiterDashboardReachable() {
        try {
            Assert.assertTrue(dashboardPage.isOnDashboard(),
                    "Recruiter should be on /recruiter/dashboard. URL: " + driver.getCurrentUrl());
            TestLogger.pass("TC-RC-01: Recruiter dashboard reachable");
        } catch (AssertionError | Exception e) {
            TestLogger.fail("TC-RC-01", e.getMessage());
            throw e;
        }
    }

    @Test(priority = 2, description = "TC-RC-02: Recruiter dashboard navbar title visible")
    public void testNavbarTitleVisible() {
        try {
            dashboardPage.open(BASE_URL);
            dashboardPage.waitForLoad();
            String title = dashboardPage.getNavbarTitle();
            Assert.assertFalse(title.isEmpty(),
                    "Navbar title should not be empty on recruiter dashboard");
            TestLogger.pass("TC-RC-02: Recruiter dashboard navbar title: " + title);
        } catch (AssertionError | Exception e) {
            TestLogger.fail("TC-RC-02", e.getMessage());
            throw e;
        }
    }

    @Test(priority = 3, description = "TC-RC-03: User chip is visible and shows role")
    public void testUserChipVisible() {
        try {
            dashboardPage.open(BASE_URL);
            Assert.assertTrue(navbarPage.isUserChipVisible(),
                    "User chip should be visible");
            String role = navbarPage.getUserRole();
            TestLogger.pass("TC-RC-03: User chip visible, role: " + role);
        } catch (AssertionError | Exception e) {
            TestLogger.fail("TC-RC-03", e.getMessage());
            throw e;
        }
    }

    @Test(priority = 4, description = "TC-RC-04: Stat cards present on recruiter dashboard")
    public void testStatCardsPresent() {
        try {
            dashboardPage.open(BASE_URL);
            dashboardPage.waitForLoad();
            int count = dashboardPage.getStatCardCount();
            Assert.assertTrue(count > 0,
                    "At least 1 stat card should be visible. Count: " + count);
            TestLogger.pass("TC-RC-04: " + count + " stat card(s) on recruiter dashboard");
        } catch (AssertionError | Exception e) {
            TestLogger.fail("TC-RC-04", e.getMessage());
            throw e;
        }
    }

    @Test(priority = 5, description = "TC-RC-05: Recruiter can navigate to /recruiter/jobs")
    public void testMyJobsPageLoads() {
        try {
            myJobsPage.open(BASE_URL);
            Assert.assertTrue(driver.getCurrentUrl().contains("/recruiter/jobs"),
                    "Should be on /recruiter/jobs");
            TestLogger.pass("TC-RC-05: My Jobs page loads");
        } catch (AssertionError | Exception e) {
            TestLogger.fail("TC-RC-05", e.getMessage());
            throw e;
        }
    }

    @Test(priority = 6, description = "TC-RC-06: My Jobs list renders without errors")
    public void testMyJobsListRenders() {
        try {
            myJobsPage.open(BASE_URL);
            myJobsPage.waitForLoad();
            // Either jobs are shown or the empty state — both are valid
            int count = myJobsPage.getJobCount();
            TestLogger.pass("TC-RC-06: My Jobs list rendered. Job count: " + count);
        } catch (AssertionError | Exception e) {
            TestLogger.fail("TC-RC-06", e.getMessage());
            throw e;
        }
    }

    @Test(priority = 7, description = "TC-RC-07: Post a Job page loads at /recruiter/jobs/new")
    public void testJobFormPageLoads() {
        try {
            jobFormPage.open(BASE_URL);
            Assert.assertTrue(driver.getCurrentUrl().contains("/jobs/new"),
                    "Should be on /recruiter/jobs/new");
            TestLogger.pass("TC-RC-07: Job form page loads");
        } catch (AssertionError | Exception e) {
            TestLogger.fail("TC-RC-07", e.getMessage());
            throw e;
        }
    }

    @Test(priority = 8, description = "TC-RC-08: Job form has title, company, description fields")
    public void testJobFormFieldsPresent() {
        try {
            jobFormPage.open(BASE_URL);
            // Typing into fields proves they exist
            jobFormPage.fillTitle("Test Job Title");
            jobFormPage.fillDescription("Test job description text");
            TestLogger.pass("TC-RC-08: Job form title and description fields present");
        } catch (AssertionError | Exception e) {
            TestLogger.fail("TC-RC-08", e.getMessage());
            throw e;
        }
    }

    @Test(priority = 9, description = "TC-RC-09: Submitting empty form stays on the form (validation)")
    public void testEmptyJobFormValidation() {
        try {
            jobFormPage.open(BASE_URL);
            jobFormPage.clickSubmit();
            WaitHelper.sleep(1500);
            // Should either show error or stay on the same page
            boolean staysOnPage = driver.getCurrentUrl().contains("/jobs/new")
                    || jobFormPage.isErrorVisible();
            Assert.assertTrue(staysOnPage,
                    "Submitting empty form should stay on the form or show error");
            TestLogger.pass("TC-RC-09: Empty form submission shows validation");
        } catch (AssertionError | Exception e) {
            TestLogger.fail("TC-RC-09", e.getMessage());
            throw e;
        }
    }

    @Test(priority = 10, description = "TC-RC-10: Role guard blocks student from recruiter routes")
    public void testRoleGuardBlocksStudent() {
        try {
            // Clear auth, login as student, try to access recruiter route
            ((org.openqa.selenium.JavascriptExecutor) driver)
                    .executeScript("localStorage.clear(); sessionStorage.clear();");
            loginPage.open(BASE_URL);
            loginPage.loginAs(STUDENT_EMAIL, STUDENT_PASSWORD);
            WaitHelper.sleep(3000);
            driver.get(BASE_URL + "/recruiter/dashboard");
            WaitHelper.sleep(2000);
            String url = driver.getCurrentUrl();
            Assert.assertFalse(url.contains("/recruiter/dashboard"),
                    "Student should not access recruiter dashboard. URL: " + url);
            TestLogger.pass("TC-RC-10: Role guard blocks student from /recruiter route. Redirected to: " + url);
            // Re-login as recruiter
            loginPage.open(BASE_URL);
            loginPage.loginAs(RECRUITER_EMAIL, RECRUITER_PASSWORD);
            WaitHelper.sleep(3000);
        } catch (AssertionError | Exception e) {
            TestLogger.fail("TC-RC-10", e.getMessage());
            throw e;
        }
    }
}
