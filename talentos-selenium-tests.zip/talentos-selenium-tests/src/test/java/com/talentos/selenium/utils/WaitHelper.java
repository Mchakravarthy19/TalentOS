package com.talentos.selenium.utils;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

/**
 * WaitHelper — Angular renders content asynchronously (via HTTP calls to
 * the Spring backend). Always use these helpers instead of raw findElement
 * to avoid NoSuchElementException / StaleElementException.
 */
public class WaitHelper {

    private final WebDriver driver;
    private final WebDriverWait wait;

    public WaitHelper(WebDriver driver) {
        this.driver = driver;
        this.wait   = new WebDriverWait(driver, Duration.ofSeconds(15));
    }

    /** Wait until element is visible, then return it. */
    public WebElement visible(By locator) {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(locator));
    }

    /** Wait until element is clickable, then return it. */
    public WebElement clickable(By locator) {
        return wait.until(ExpectedConditions.elementToBeClickable(locator));
    }

    /** Wait for URL to contain a substring (after navigation / redirect). */
    public void urlContains(String fragment) {
        wait.until(ExpectedConditions.urlContains(fragment));
    }

    /** Wait until element disappears (e.g. spinner / loader). */
    public void gone(By locator) {
        wait.until(ExpectedConditions.invisibilityOfElementLocated(locator));
    }

    /** Pause for a fixed duration — use sparingly. */
    public static void sleep(long ms) {
        try { Thread.sleep(ms); } catch (InterruptedException ignored) {}
    }
}
