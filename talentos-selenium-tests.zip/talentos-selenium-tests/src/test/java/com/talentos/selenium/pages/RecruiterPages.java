package com.talentos.selenium.pages;

import com.talentos.selenium.utils.WaitHelper;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import java.util.List;

/**
 * RecruiterPages — covers:
 *   - recruiter-dashboard.component.html
 *   - my-jobs.component.html
 *   - job-form.component.html
 */
public class RecruiterPages {

    // ── Recruiter Dashboard ─────────────────────────────────────────────────
    public static class DashboardPage {
        private final WebDriver driver;
        private final WaitHelper wait;

        private final By navbarTitle  = By.cssSelector("header.topbar h5");
        private final By statCards    = By.cssSelector(".stat-card");
        private final By loader       = By.cssSelector("app-loader");
        private final By postJobBtn   = By.cssSelector("a[routerlink*='jobs/new'], button[routerlink*='jobs/new'], a[href*='jobs/new']");

        public DashboardPage(WebDriver driver) {
            this.driver = driver;
            this.wait   = new WaitHelper(driver);
        }

        public void open(String baseUrl) {
            driver.get(baseUrl + "/recruiter/dashboard");
        }

        public void waitForLoad() { wait.gone(loader); }

        public String getNavbarTitle() {
            return wait.visible(navbarTitle).getText();
        }

        public int getStatCardCount() {
            return driver.findElements(statCards).size();
        }

        public boolean isOnDashboard() {
            return driver.getCurrentUrl().contains("/recruiter/dashboard");
        }
    }

    // ── Job Form (Post / Edit a job) ────────────────────────────────────────
    public static class JobFormPage {
        private final WebDriver driver;
        private final WaitHelper wait;

        private final By titleInput    = By.cssSelector("input[formcontrolname='title']");
        private final By companyInput  = By.cssSelector("input[formcontrolname='companyName']");
        private final By locationInput = By.cssSelector("input[formcontrolname='location']");
        private final By ctcInput      = By.cssSelector("input[formcontrolname='ctc']");
        private final By descTextarea  = By.cssSelector("textarea[formcontrolname='description']");
        private final By jobTypeSelect = By.cssSelector("select[formcontrolname='jobType']");
        private final By submitBtn     = By.cssSelector("button[type='submit']");
        private final By successAlert  = By.cssSelector(".alert.alert-success");
        private final By errorAlert    = By.cssSelector(".alert.alert-danger");
        private final By pageHeading   = By.cssSelector("h2, h1");

        public JobFormPage(WebDriver driver) {
            this.driver = driver;
            this.wait   = new WaitHelper(driver);
        }

        public void open(String baseUrl) {
            driver.get(baseUrl + "/recruiter/jobs/new");
        }

        public void fillTitle(String title) {
            wait.visible(titleInput).clear();
            wait.visible(titleInput).sendKeys(title);
        }

        public void fillCompany(String company) {
            wait.visible(companyInput).clear();
            wait.visible(companyInput).sendKeys(company);
        }

        public void fillLocation(String location) {
            wait.visible(locationInput).clear();
            wait.visible(locationInput).sendKeys(location);
        }

        public void fillCtc(String ctc) {
            List<WebElement> els = driver.findElements(ctcInput);
            if (!els.isEmpty()) { els.get(0).clear(); els.get(0).sendKeys(ctc); }
        }

        public void fillDescription(String desc) {
            wait.visible(descTextarea).clear();
            wait.visible(descTextarea).sendKeys(desc);
        }

        public void selectJobType(String type) {
            new Select(wait.visible(jobTypeSelect)).selectByValue(type);
        }

        public void clickSubmit() {
            wait.clickable(submitBtn).click();
        }

        public boolean isSuccessVisible() {
            return !driver.findElements(successAlert).isEmpty();
        }

        public boolean isErrorVisible() {
            return !driver.findElements(errorAlert).isEmpty();
        }
    }

    // ── My Jobs list ────────────────────────────────────────────────────────
    public static class MyJobsPage {
        private final WebDriver driver;
        private final WaitHelper wait;

        private final By jobRows   = By.cssSelector(".job-row, .job-card, tr.job-item");
        private final By postBtn   = By.cssSelector("a[routerlink*='jobs/new'], button[routerlink*='jobs/new']");
        private final By loader    = By.cssSelector("app-loader");
        private final By emptyMsg  = By.cssSelector(".empty-state, .no-jobs");

        public MyJobsPage(WebDriver driver) {
            this.driver = driver;
            this.wait   = new WaitHelper(driver);
        }

        public void open(String baseUrl) {
            driver.get(baseUrl + "/recruiter/jobs");
        }

        public void waitForLoad() { wait.gone(loader); }

        public int getJobCount() {
            return driver.findElements(jobRows).size();
        }

        public boolean isEmptyStateVisible() {
            return !driver.findElements(emptyMsg).isEmpty();
        }
    }
}
