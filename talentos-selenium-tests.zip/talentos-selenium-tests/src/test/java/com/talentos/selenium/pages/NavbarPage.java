package com.talentos.selenium.pages;

import com.talentos.selenium.utils.WaitHelper;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

/**
 * NavbarPage — covers the shared topbar (navbar.component.html)
 * and sidebar navigation links present on all authenticated pages.
 */
public class NavbarPage {

    private final WebDriver driver;
    private final WaitHelper wait;

    // Topbar elements
    private final By pageTitle     = By.cssSelector("header.topbar h5");
    private final By notifBtn      = By.cssSelector("button.notif-btn");
    private final By userChip      = By.cssSelector(".user-chip");
    private final By userName      = By.cssSelector(".user-chip .name");
    private final By userRole      = By.cssSelector(".user-chip .role");
    private final By userAvatar    = By.cssSelector(".user-avatar");

    // Sidebar nav links (sidebar.component.html uses routerLink)
    private final By dashboardLink = By.cssSelector("a[routerlink*='dashboard']");
    private final By jobsLink      = By.cssSelector("a[routerlink*='jobs']");
    private final By profileLink   = By.cssSelector("a[routerlink*='profile']");
    private final By notifsLink    = By.cssSelector("a[routerlink*='notifications']");
    private final By logoutBtn     = By.cssSelector("button.logout-btn, a.logout-btn, [class*='logout']");

    public NavbarPage(WebDriver driver) {
        this.driver = driver;
        this.wait   = new WaitHelper(driver);
    }

    public String getPageTitle() {
        return wait.visible(pageTitle).getText();
    }

    public String getUserName() {
        return wait.visible(userName).getText();
    }

    public String getUserRole() {
        return wait.visible(userRole).getText();
    }

    public boolean isUserChipVisible() {
        return !driver.findElements(userChip).isEmpty();
    }

    public void clickNotifications() {
        wait.clickable(notifBtn).click();
    }

    public boolean isNotificationBellVisible() {
        return !driver.findElements(notifBtn).isEmpty();
    }

    public void goToDashboard() {
        wait.clickable(dashboardLink).click();
    }

    public void goToJobs() {
        wait.clickable(jobsLink).click();
    }

    public void goToProfile() {
        wait.clickable(profileLink).click();
    }

    public void goToNotifications() {
        wait.clickable(notifsLink).click();
    }

    public void logout() {
        wait.clickable(logoutBtn).click();
    }
}
