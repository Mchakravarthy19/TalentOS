package com.talentos.selenium.utils;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * TestLogger — writes PASS / FAIL results to logs/test-results.log
 * Called from every test method so you get a clear human-readable log file.
 */
public class TestLogger {

    private static final String LOG_FILE = "logs/test-results.log";
    private static final DateTimeFormatter FMT =
            DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    public static void pass(String testName) {
        write("PASS", testName, "");
    }

    public static void fail(String testName, String reason) {
        write("FAIL", testName, reason);
    }

    public static void info(String message) {
        write("INFO", message, "");
    }

    public static void separator(String suiteName) {
        String line = "\n" + "=".repeat(70) + "\n"
                + "  SUITE: " + suiteName + "\n"
                + "  Started: " + LocalDateTime.now().format(FMT) + "\n"
                + "=".repeat(70);
        write("", line, "");
    }

    private static void write(String level, String message, String extra) {
        try (PrintWriter pw = new PrintWriter(new FileWriter(LOG_FILE, true))) {
            String timestamp = LocalDateTime.now().format(FMT);
            if (level.isEmpty()) {
                pw.println(message);
            } else {
                String entry = String.format("[%s] [%-4s] %s%s",
                        timestamp,
                        level,
                        message,
                        extra.isEmpty() ? "" : " — " + extra);
                pw.println(entry);
                System.out.println(entry);   // also echoes to console
            }
        } catch (IOException e) {
            System.err.println("TestLogger could not write to " + LOG_FILE + ": " + e.getMessage());
        }
    }
}
