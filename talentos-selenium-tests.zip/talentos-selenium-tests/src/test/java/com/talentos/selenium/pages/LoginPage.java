package com.talentos.selenium.pages;

import com.talentos.selenium.utils.WaitHelper;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

/**
 * LoginPage — matches login.component.html
 *
 * Locators:
 *   Email:    input[formControlName="email"]   (type="email")
 *   Password: input[formControlName="password"]
 *   Submit:   button.btn-auth-submit
 *   Error:    .alert.alert-danger span
 *   Register link: a[routerLink="/register"]
 */
public class LoginPage {

    private final WebDriver driver;
    private final WaitHelper wait;

    private final By emailInput    = By.cssSelector("input[formcontrolname='email']");
    private final By passwordInput = By.cssSelector("input[formcontrolname='password']");
    private final By submitBtn     = By.cssSelector("button.btn-auth-submit");
    private final By errorAlert    = By.cssSelector(".alert.alert-danger span");
    private final By registerLink  = By.cssSelector("a[href='/register']");
    private final By brandName     = By.cssSelector(".auth-brand-name");
    private final By formTitle     = By.cssSelector(".auth-form-title");

    public LoginPage(WebDriver driver) {
        this.driver = driver;
        this.wait   = new WaitHelper(driver);
    }

    public void open(String baseUrl) {
        driver.get(baseUrl + "/login");
    }

    public void enterEmail(String email) {
        wait.visible(emailInput).clear();
        wait.visible(emailInput).sendKeys(email);
    }

    public void enterPassword(String password) {
        wait.visible(passwordInput).clear();
        wait.visible(passwordInput).sendKeys(password);
    }

    public void clickSubmit() {
        wait.clickable(submitBtn).click();
    }

    public void loginAs(String email, String password) {
        enterEmail(email);
        enterPassword(password);
        clickSubmit();
    }

    public String getErrorMessage() {
        return wait.visible(errorAlert).getText();
    }

    public String getBrandName() {
        return wait.visible(brandName).getText();
    }

    public String getFormTitle() {
        return wait.visible(formTitle).getText();
    }

    public boolean isOnLoginPage() {
        return driver.getCurrentUrl().contains("/login");
    }

    public void clickRegisterLink() {
        wait.clickable(registerLink).click();
    }
}
