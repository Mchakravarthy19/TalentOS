package com.talentos.selenium.tests;

import com.talentos.selenium.config.BaseTest;
import com.talentos.selenium.pages.LoginPage;
import com.talentos.selenium.utils.TestLogger;
import com.talentos.selenium.utils.WaitHelper;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

/**
 * NavigationTest — tests Angular routing, AuthGuard, and RoleGuard.
 *
 * Test cases:
 *   TC-NAV-01  Unknown route /xyz redirects to /login
 *   TC-NAV-02  AuthGuard blocks /student/profile when not logged in
 *   TC-NAV-03  AuthGuard blocks /recruiter/jobs when not logged in
 *   TC-NAV-04  AuthGuard blocks /admin/users when not logged in
 *   TC-NAV-05  Student sidebar notification link navigates to /student/notifications
 *   TC-NAV-06  Student sidebar jobs link navigates to /student/jobs
 *   TC-NAV-07  My Applications link navigates to /student/applications
 *   TC-NAV-08  Browser back button works after Angular navigation
 */
public class NavigationTest extends BaseTest {

    private LoginPage loginPage;

    @BeforeClass
    public void setup() {
        TestLogger.separator("NAVIGATION / ROUTING TESTS");
        loginPage = new LoginPage(driver);
    }

    private void clearAuth() {
        ((org.openqa.selenium.JavascriptExecutor) driver)
                .executeScript("localStorage.clear(); sessionStorage.clear();");
    }

    @Test(priority = 1, description = "TC-NAV-01: Unknown route redirects to /login")
    public void testUnknownRouteRedirects() {
        try {
            clearAuth();
            driver.get(BASE_URL + "/this/does/not/exist");
            WaitHelper.sleep(1500);
            Assert.assertTrue(driver.getCurrentUrl().contains("/login"),
                    "Unknown route should redirect to /login");
            TestLogger.pass("TC-NAV-01: Unknown route → /login");
        } catch (AssertionError | Exception e) {
            TestLogger.fail("TC-NAV-01", e.getMessage());
            throw e;
        }
    }

    @Test(priority = 2, description = "TC-NAV-02: AuthGuard blocks /student/profile when unauthenticated")
    public void testAuthGuardBlocksStudentProfile() {
        try {
            clearAuth();
            driver.get(BASE_URL + "/student/profile");
            WaitHelper.sleep(1500);
            Assert.assertTrue(driver.getCurrentUrl().contains("/login"),
                    "/student/profile should be blocked and redirect to /login");
            TestLogger.pass("TC-NAV-02: AuthGuard blocks /student/profile");
        } catch (AssertionError | Exception e) {
            TestLogger.fail("TC-NAV-02", e.getMessage());
            throw e;
        }
    }

    @Test(priority = 3, description = "TC-NAV-03: AuthGuard blocks /recruiter/jobs when unauthenticated")
    public void testAuthGuardBlocksRecruiterJobs() {
        try {
            clearAuth();
            driver.get(BASE_URL + "/recruiter/jobs");
            WaitHelper.sleep(1500);
            Assert.assertTrue(driver.getCurrentUrl().contains("/login"),
                    "/recruiter/jobs should be blocked");
            TestLogger.pass("TC-NAV-03: AuthGuard blocks /recruiter/jobs");
        } catch (AssertionError | Exception e) {
            TestLogger.fail("TC-NAV-03", e.getMessage());
            throw e;
        }
    }

    @Test(priority = 4, description = "TC-NAV-04: AuthGuard blocks /admin/users when unauthenticated")
    public void testAuthGuardBlocksAdminUsers() {
        try {
            clearAuth();
            driver.get(BASE_URL + "/admin/users");
            WaitHelper.sleep(1500);
            Assert.assertTrue(driver.getCurrentUrl().contains("/login"),
                    "/admin/users should be blocked");
            TestLogger.pass("TC-NAV-04: AuthGuard blocks /admin/users");
        } catch (AssertionError | Exception e) {
            TestLogger.fail("TC-NAV-04", e.getMessage());
            throw e;
        }
    }

    @Test(priority = 5, description = "TC-NAV-05: After student login, /student/notifications is accessible")
    public void testStudentNotificationsAccessible() {
        try {
            loginPage.open(BASE_URL);
            loginPage.loginAs(STUDENT_EMAIL, STUDENT_PASSWORD);
            WaitHelper.sleep(3000);
            driver.get(BASE_URL + "/student/notifications");
            WaitHelper.sleep(2000);
            Assert.assertTrue(driver.getCurrentUrl().contains("/student/notifications"),
                    "Should reach /student/notifications");
            TestLogger.pass("TC-NAV-05: /student/notifications accessible after login");
        } catch (AssertionError | Exception e) {
            TestLogger.fail("TC-NAV-05", e.getMessage());
            throw e;
        }
    }

    @Test(priority = 6, description = "TC-NAV-06: /student/jobs is accessible after login")
    public void testStudentJobsAccessible() {
        try {
            driver.get(BASE_URL + "/student/jobs");
            WaitHelper.sleep(2000);
            Assert.assertTrue(driver.getCurrentUrl().contains("/student/jobs"),
                    "Should reach /student/jobs");
            TestLogger.pass("TC-NAV-06: /student/jobs accessible");
        } catch (AssertionError | Exception e) {
            TestLogger.fail("TC-NAV-06", e.getMessage());
            throw e;
        }
    }

    @Test(priority = 7, description = "TC-NAV-07: /student/applications is accessible after login")
    public void testStudentApplicationsAccessible() {
        try {
            driver.get(BASE_URL + "/student/applications");
            WaitHelper.sleep(2000);
            Assert.assertTrue(driver.getCurrentUrl().contains("/student/applications"),
                    "Should reach /student/applications");
            TestLogger.pass("TC-NAV-07: /student/applications accessible");
        } catch (AssertionError | Exception e) {
            TestLogger.fail("TC-NAV-07", e.getMessage());
            throw e;
        }
    }

    @Test(priority = 8, description = "TC-NAV-08: Browser back button works after Angular navigation")
    public void testBrowserBackButton() {
        try {
            driver.get(BASE_URL + "/student/dashboard");
            WaitHelper.sleep(1500);
            driver.get(BASE_URL + "/student/jobs");
            WaitHelper.sleep(1500);
            driver.navigate().back();
            WaitHelper.sleep(1500);
            Assert.assertTrue(driver.getCurrentUrl().contains("/student/dashboard"),
                    "Back button should return to /student/dashboard");
            TestLogger.pass("TC-NAV-08: Browser back button works");
        } catch (AssertionError | Exception e) {
            TestLogger.fail("TC-NAV-08", e.getMessage());
            throw e;
        }
    }
}
